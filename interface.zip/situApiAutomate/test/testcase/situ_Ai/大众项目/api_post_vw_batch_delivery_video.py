#coding=utf-8
# author:liucaiyu
import unittest
import requests
from lib.generateTestCases import __generateTestCases
from lib.log import logger
from config import situ_AI_url


##审查任务单个视频提交
class ApiBatchDelivery(unittest.TestCase):
    """审查任务单个视频提交-刘才宇"""
    def setUp(self):
        logger.info("*" * 80)
    def getTest(self,data):
        logger.info("***************网关请求审查任务单个视频提交开始****************")
        case = data['case']
        num=data['tc_num']
        name=data['tc_name']
        code=int(data['code'])
        fileType=data['fileType']
        operator=data['operator']
        address = data["address"]
        damage = data['damage']
        vin = data['vin']
        logger.info(num + "_" + name + "_" + case)
        osFile = situ_AI_url.post_vw_file_delivery(address, case, fileType)
        # headers={"Content-Type":"application/json"}
        params = {"pplVerNo": "Y.Z","fileType": fileType,"operator": operator,"osFile":osFile,"damage":damage,"vin":vin,}
        logger.info(params)
        requests.packages.urllib3.disable_warnings()
        res = requests.post(url=situ_AI_url.get_vw_base_url(case)+situ_AI_url.batch_delivery, data=params,verify=False)
        logger.info(res.text)
        result = res.json()
        logger.info("*******返回数据： " + str(result))
        self.assertEqual(result['code'],code)
        logger.info("****************网关请求审查任务单个视频提交结束****************")
    @staticmethod
    def getTestFunc(arg1):
        def func(self):
            self.getTest(arg1)
        return func

    def tearDown(self):
        logger.info("*" * 80)

__generateTestCases(ApiBatchDelivery, "batch_delivery",  "api_vm.xlsx", "审查任务单个视频提交")
