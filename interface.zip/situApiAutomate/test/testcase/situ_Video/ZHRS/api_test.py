# coding=utf-8

import requests

from config import situ_ZHRS_url
from lib.generateTestCases import __generateTestCases
from lib.log import logger
from lib.tmp import ApiTmp


class ApiTest(ApiTmp):
    def getTest(self, data):
        logger.info("***************网关请求中宏APP-业务员端账号激活开始****************")
        case = data['case']
        num = data['tc_num']
        name = data['tc_name']
        code = int(data['code'])
        username = data['username']
        phoneNum = data['phoneNum']
        validateCode = data['validateCode']
        password = data['password']
        logger.info(num + "_" + name + "_" + case)
        headers = {"Content-Type": "application/json", "X-Device": "Xiaomi/MI 9/10"}
        params = {"username": username, "phoneNum": phoneNum, "validateCode": validateCode, "password": password}
        logger.info(params)
        requests.packages.urllib3.disable_warnings()
        res = requests.post(url=situ_ZHRS_url.get_ZHRS_base_url(case) + situ_ZHRS_url.manulife_account_activate,
                            headers=headers, json=params, verify=False)
        logger.info(situ_ZHRS_url.get_ZHRS_base_url(case) + situ_ZHRS_url.manulife_account_activate)
        logger.info(res.text)
        result = res.json()
        logger.info("*******返回数据： " + str(result))
        self.assertEqual(result['code'], code)
        logger.info("****************网关请求中宏APP-业务员端账号激活结束****************")


__generateTestCases(ApiTest, "manulife_account_activate", "api_ZHRS.xlsx", "账号激活")
