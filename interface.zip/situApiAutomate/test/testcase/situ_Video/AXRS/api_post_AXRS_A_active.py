#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020-10-16 18:17
# @Author : 付孟奇

import unittest,requests
from config import situ_AXRS_url
from lib.log import logger
from lib.generateTestCases import __generateTestCases

class A_active(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        logger.info("A端-----账号激活-----接口测试开始！")

    def activeTest(self,data):
        #Excel中case的固定参数
        num = data['tc_num']
        name = data['tc_name']
        case = data['case']
        code = int(data['code'])
        #Excel中case的可变参数
        userName = data['username']
        passwd = int(data['password'])
        phoneNum = data['phoneNum']
        validateCode = int(data['validateCode'])

        headers = {
            'Content-Type': 'application/json'
        }
        payload = {
            "username": userName,
            "password": passwd,
            'validateCode':validateCode,
            'phoneNum':phoneNum
        }
        url = situ_AXRS_url.aixin_staging_baseURL+situ_AXRS_url.A_active
        logger.info('请求参数为：'+str(payload))
        response = requests.request('POST',url,headers=headers,json=payload)
        res = response.json()
        self.assertEqual(res['code'],code,msg='校验失败！')
        logger.info("接口返回参数为："+str(res))

    @staticmethod
    def getTestFunc(arg1):
        def func(self):
            self.activeTest(arg1)
        return func

__generateTestCases(A_active,'A端_forget','api_AXRS.xlsx','A端--账号激活')

if __name__ == '__main__':
    unittest.main()
    # suite = unittest.TestSuite()
    # suite.addTest(A_login('test_login'))
    # runner = unittest.TextTestRunner()
    # runner.run(suite)