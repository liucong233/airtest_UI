#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020-11-19 16:30
# @Author : 付孟奇

import sys

def get_config():
    config_info = {

    }
    #Jenkins参数
    if len(sys.argv) > 1:
        config_info['pro'] = sys.argv[1]
        config_info['env'] = sys.argv[2]
        config_info['email'] = sys.argv[3]
        config_info['title'] = sys.argv[4]
    else:
        #本地兼容
        config_info['pro'] = 'ZHRS/'
        config_info['env'] = 'staging'
        config_info['email'] = 'fumengqi@situdata.com,liucaiyu@situdata.com'
        config_info['title'] = '本地调试'
    return config_info


config = get_config()