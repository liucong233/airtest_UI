#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020-11-11 16:24
# @Author : 付孟奇
import pymysql
from lib.log import logger

class DataBase():
    #中宏数据库链接
    def data_base(self,case,sqls,fe):
        if case == 'staging':
            username = 'manulife'
            passwd = 'I8YjqoEoQXbMHOIp'
            db = 'manulife'
        if case == 'beta':
            username = 'manulife_beta'
            passwd = 'D419Pu018Gx1615Cd%baWgle'
            db = 'manulife_beta'
        conn = pymysql.connect(host='rm-2zen60zh797n662w4lo.mysql.rds.aliyuncs.com',
                               port=3306,
                               user=username,
                               passwd=passwd,
                               db=db,
                               cursorclass=pymysql.cursors.DictCursor)
        logger.info('连接成功!')
        with conn.cursor() as cur:
            cur.execute(sqls)
            if fe=='SELECT':
                result = cur.fetchall()
                return result
            elif fe =='DELETE':
                conn.commit()
            cur.close()
            conn.close()


    #查询订单信息
    def select_order(self,case,username):
        fe = 'SELECT'
        # 获取补录订单(节点补录、整单补录、复核补录、复核重录)
        sql = '''select id from order_base_info where salesman_username='%s' and life_cycle in('11','12','35','36') ''' % (username)
        logger.info(sql)
        result = self.data_base(case,sql,fe)
        logger.info(result)
        return result[0]['id']

    #查询产品附加属性id
    def select_produce(self,case,plId,akId):
        fe = 'SELECT'
        sql = '''SELECT id FROM product_additional_attributes_value where pl_id=%s and paak_id=%s''' % (plId, akId)
        logger.info(sql)
        result = self.data_base(case, sql,fe)
        logger.info(result)
        avId = result[0]['id']
        return avId

    #删除产品
    def delete_product(self,case,arg):
        fe = 'DELETE'
        sql = '''DELETE from product_library where product_code='%s' ''' % (arg)
        logger.info(sql)
        self.data_base(case, sql, fe)

    #查询话术
    def select_template(self,case,arg):
        fe = 'SELECT'
        sql ='''SELECT id FROM speech_template_library WHERE speech_name='%s' ''' % (arg)
        logger.info(sql)
        result = self.data_base(case,sql,fe)
        logger.info(result)
        stlId = result[0]['id']
        return stlId

    #删除话术
    def delete_template(self,case,arg):
        fe ='DELETE'
        sql = '''DELETE  FROM speech_template_library WHERE speech_name='%s' ''' % (arg)
        logger.info(sql)
        self.data_base(case, sql, fe)


dataBase = DataBase()
if __name__ == '__main__':
    # dataBase.conn2('staging1',47,31)
    # dataBase.conn1('staging','006')
    # dataBase.delete_product('staging','APITest')
    # dataBase.select_template('staging','自动化测试')
    dataBase.delete_template('staging','自动化测试')

