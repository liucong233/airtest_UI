#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020-10-21 11:08
# @Author : 付孟奇

import requests
from lib.log import logger
from lib import read_write_json
from lib.read_write_json import file_read
from lib.RandomID import timeStamp_13
from config import situ_ZHRS_url


'''中宏登陆Token'''
def get_ZHRS_token(username, password, case, deviceNum):
    params = {
          "username": username,
          "password": password,
          "deviceNum": deviceNum
          }
    # logger.info('中宏登陆参数：'+str(params))
    headers = {"Content-Type": "application/json"}
    url = situ_ZHRS_url.get_ZHRS_base_url(case)+situ_ZHRS_url.manulife_login
    response = requests.post(url,json=params, headers=headers, verify=False)
    res = response.json()
    # logger.info("封装的生成订单接口返回参数为：" + str(res))
    token = res['result']['token']
    # 传递参数['json文件路径'，'json文件待更新字段'，'待更新数据值']
    read_write_json.file_hand('/global_parameter.json','ZHRS_token',token)
    return token

'''定制手机号token'''
def get_ZHRS_token_phone(username, password, case, deviceNum,phone):
    params = {
          "username": username,
          "password": password,
          "deviceNum": deviceNum
          }
    # logger.info('中宏登陆参数：'+str(params))
    headers = {"Content-Type": "application/json"}
    url = situ_ZHRS_url.get_ZHRS_base_url(case)+situ_ZHRS_url.manulife_login
    response = requests.post(url,json=params, headers=headers, verify=False)
    res = response.json()
    # logger.info("封装的生成订单接口返回参数为：" + str(res))
    token = res['result']['token']
    return token

#中宏B端登陆
def get_ZHRS_B_token(case):
    payload = {
        "phoneNum": "15737319294",
        "idNo": "7863",
        "validCode": "654987"
    }
    headers = {"Content-Type": "application/json"}
    url = situ_ZHRS_url.get_ZHRS_base_url(case)+situ_ZHRS_url.manulife_remote_login
    response = requests.request('POST', url, headers=headers, json=payload)
    res = response.json()
    logger.info("封装的B端token接口返回参数为：" + str(res))
    ZHRS_B_Token = res['result']['token']
    try:
        # 传递参数['json文件路径'，'json文件待更新字段'，'待更新数据值']
        read_write_json.file_hand('/global_parameter.json','ZHRS_B_Token',ZHRS_B_Token)
        return ZHRS_B_Token
    except:
        logger.info(res['msg'])

#中宏web端登陆
def get_ZHRS_WEB_token(case):
    headers = {
        'Content-Type': 'application/json'
    }
    payload = {
        "username": "Cs01",
        "password": "1234567"
    }
    url = situ_ZHRS_url.get_ZHRS_base_url(case) + situ_ZHRS_url.manulife_web_login
    response = requests.request('POST', url, headers=headers, json=payload)
    res = response.json()
    ZHRS_WEB_Token = res['result']['token']
    # 传递参数['json文件路径'，'待更新字段'，'待更新数据值']
    read_write_json.file_hand('/global_parameter.json', 'ZHRS_WEB_Token', ZHRS_WEB_Token)
    return ZHRS_WEB_Token


#判断登陆的token是否有效
def isVaild(pro,case):
    ZHRS_RecordBeginTime = file_read('/global_parameter.json','ZHRS_token')
    nowTime = timeStamp_13
    subTime = nowTime-ZHRS_RecordBeginTime
    if subTime>'3600000':
        if pro=='ZH':
            get_ZHRS_B_token(case)


if __name__ == '__main__':
    get_ZHRS_token('006','12345678','beta','11')