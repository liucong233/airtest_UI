#!/usr/bin/env python
# encoding: utf-8

'''
@author: liucaiyu
@time: 2020/10/21 17:58
'''
import requests
import json
from lib.log import logger
from lib.read_write_json import file_read
from config import situ_ZHRS_url

##发送中宏人寿对应手机号的验证码（忘记密码），手机号为A端手机号
def get_ZHRS_send_sms(case,type,phoneNum):
    params = {"phoneNum": phoneNum, "type": type}
    headers= {"Content-Type":"application/json"}
    requests.packages.urllib3.disable_warnings()
    res = requests.post(url=situ_ZHRS_url.get_ZHRS_base_url(case) +situ_ZHRS_url.manulife_send_sms, json=params,headers=headers,verify=False)
    logger.info(res.text)
    # bs = BeautifulSoup(res.text, "lxml")  # 将请求结果传递给bs构造对象
    # res1= bs.script.text[21:][:-6]##对象中获取script的字符串，并进行截取
    res2=json.loads(res.text)##转化为json
    # result=res2['result']['token']
    logger.info(res2)
    return res2

#中宏人寿发送短信通知B端，手机号为B端手机号
def get_ZHRS_notify_remote(case):
    phoneNum = '15737319294'
    login_token = file_read('/global_parameter.json', 'ZHRS_token')
    orderRecordId = file_read('/global_parameter.json', 'ZHRS_orderRecordId')
    headers = {
        'Content-Type': 'application/json',
        'X-Auth-Token': login_token
    }
    payload = {
        "phoneNum": phoneNum,
        "orderRecordId": int(orderRecordId)
    }
    url = situ_ZHRS_url.get_ZHRS_base_url(case) + situ_ZHRS_url.manulife_order_notify_remote
    response = requests.request('POST', url, headers=headers, json=payload)
    res = response.json()
    # logger.info("发送短信通知B端接口返回参数为：" + str(res))
    return res['code']

if __name__ == '__main__':
    get_ZHRS_send_sms("staging",'2')