#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020-10-21 15:33
# @Author : 付孟奇

import json
from config.config import datapath

'''读写global的json文件'''
#传递参数['json文件路径'，'json待更新字段'，'待更新数据值']
def file_hand(path,up_field,up_data):
    with open(datapath + path, 'r+') as f:
        file_data = json.load(f)
        file_data[up_field] = up_data
        f.seek(0)
        f.truncate()
        json.dump(file_data, f, ensure_ascii=False)

'''读global的json文件的指定内容'''
#传递参数['json文件路径'，'json指定字段'，'待更新数据值']
def file_read(path,up_field):
    with open(datapath + path, 'r') as f:
        file_data = json.load(f)
        datas = file_data[up_field]
    return datas

'''读所有读json文件'''
def file_readALL(path):
    with open(datapath + path, 'r') as f:
        file_data = json.load(f)
    return file_data

