#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020-10-21 11:09
# @Author : 付孟奇

import requests,json
from lib.log import logger
from lib import RandomID
from lib.BaseLoginToken import get_ZHRS_token
from lib import read_write_json
from config import config
from config import situ_ZHRS_url

'''中宏订单'''
def orderAddTest(case):
    #获取json文件中的信息
    with open(config.datapath+'/ZHRS_orderAdd.json','rb') as f:
        file_data = json.load(f)
        #参数处理
        file_data['data'][0]['subInfo'] =RandomID.timeStamp_10()
        file_data['data'][3]['subInfo']['保单号'] = file_data['data'][0]['subInfo']
        file_data['data'][3]['subInfo']['投保单号'] = file_data['data'][0]['subInfo']
        # logger.info('生成订单的报文为：'+str(file_data))
    username = '006'
    passwd = '12345678'
    deviceNum = '1234'
    login_token=get_ZHRS_token(username,passwd,case,deviceNum)
    headers = {
        'Content-Type': 'application/json',
        'X-Auth-Token':login_token
    }

    url = situ_ZHRS_url.get_ZHRS_base_url(case)+situ_ZHRS_url.manulife_order_add
    response = requests.request('POST',url,headers=headers,json=file_data)
    res = response.json()
    # logger.info("封装的生成订单接口返回参数为：" + str(res))
    ZHRS_orderID = res['result']['orderId']
    ZHRS_orderRecordId = res['result']['orderRecordId']

    # 传递参数['json文件路径'，'待更新字段'，'待更新数据值']
    read_write_json.file_hand('/global_parameter.json', 'ZHRS_orderId', ZHRS_orderID)
    read_write_json.file_hand('/global_parameter.json', 'ZHRS_orderRecordId', ZHRS_orderRecordId)
    return ZHRS_orderRecordId

if __name__ == '__main__':
    case = "staging"
    id = orderAddTest(case)
    print(id)