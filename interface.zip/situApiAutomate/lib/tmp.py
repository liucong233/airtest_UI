# coding=utf-8
import unittest

from lib.log import logger


class ApiTmp(unittest.TestCase):

    def setUp(self):
        logger.info("*" * 80)

    @staticmethod
    def getTestFunc(arg1):
        def func(self):
            self.getTest(arg1)

        return func

    def tearDown(self):
        logger.info("*" * 80)
