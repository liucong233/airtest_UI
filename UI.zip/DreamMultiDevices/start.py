# -*- coding: utf-8 -*-
# author:lcy

import sys, os
from core import index


def start():
    index.main()


# 从根目录启动，确保相对路径调用正常
if __name__ == '__main__':
    start()
    # os.popen("adb start-server")
