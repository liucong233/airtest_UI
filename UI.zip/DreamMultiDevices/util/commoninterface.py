# -*- coding: utf-8 -*-
# author:lcy

from tools import mysqldb
import random
import json
import requests
import base64
import time
from core.MultiAdb import MultiAdb as madb
# hmlt_base_url = "http://api.dev.haimaliaotian.com/"
hmlt_base_url = "http://azure-api.haimaliaotian.com/"
hmlt_base_admin_url = "http://azure-admin.haimaliaotian.com"

requests.packages.urllib3.disable_warnings()


# 获取图形验证码
def captcha():
    captchares = requests.get(hmlt_base_url + "api/v2/captcha/dt")
    sid = captchares.json()['sid']
    url = captchares.json()['url']
    # print("验证码："+url)
    captchares = requests.get(url)
    # print(captchares.content)
    if (captchares.status_code == 200):
        return sid
    else:
        return captchares.status_code


# 获取短信验证码
def sms(phone):
    url = hmlt_base_url + 'api/v2/verifycodes/register'
    headers = {"Content-Type": "application/json"}
    params = {"captcha": '0000', 'phone': phone, 'sid': captcha()}
    # params = json.dumps(params)
    rgres = requests.post(url=url, headers=headers, params=params, verify=False)
    # print(rgres.status_code)
    # print(rgres.json())
    if rgres.status_code == 202:
        return 'ok'
    else:
        #       return rgres.json()["message"]
        return rgres.status_code


# 随机生成手机号码（选一个自己测试的手机号段）
def getRandomPhone():
    """随机生成手机号码"""
    return "1682006" + "".join(random.choice("0123456789") for i in range(4))


# 修改用户昵称为手机号
def changeUsername(phone, token):
    url = hmlt_base_url + '/api/v2/user'
    headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'Accept': "application/json",
        'Authorization': "Bearer " + token
    }
    payload = "name=haima" + phone + "&bio=hello!" + phone
    res = requests.request("PATCH", url, data=payload, headers=headers)
    if res.status_code == 204:
        print("昵称修改成功：haima" + phone)


# 注册
def register():
    phone = getRandomPhone()
    url = hmlt_base_url + 'api/v2/users'

    headers = {"Content-Type": "application/json"}
    params = {'phone': phone, 'password': '123456', 'verifiable_code': '123456', 'verifiable_type': 'sms'}
    message = sms(phone)

    while message != "ok":
        phone = getRandomPhone()
        message = sms(phone)

    if message == 'ok':
        urres = requests.post(url=url, headers=headers, params=params, verify=False)
        if urres.status_code == 201:
            token = urres.json()['token']
            print("------" + str(phone) + '注册成功，token是：' + token + "------")
            changeUsername(phone, token)
            return phone
        else:
            print(urres.json())
    else:
        print(message)


# def batchRegister(num,phone):
#     num = int(num)
#     phone = int(phone)
#
#     for i in range(num):
#         register(phone)
#         phone += 1

# 获取未认证的用户
def noAuth():
    personAuth = "SELECT phone FROM qywl.users where verifyStatus= 0 AND relationCompany=0 and (phone>='16820060000' and phone<='16820069999');"
    data = mysqldb.mysqldb("qywl").selectsql(personAuth)
    return random.choice(data)["phone"]


# 获取一个个人认证用户的手机号
def personAuth():
    personAuth = "SELECT phone FROM qywl.users where verifyStatus= 1 AND relationCompany=0;"
    data = mysqldb.mysqldb("qywl").selectsql(personAuth)
    return random.choice(data)["phone"]


# print(personAuth())


# 获取一个企业认证用户的手机号
def companyAuth():
    flag = 1
    while flag:
        verifyAuth = "SELECT count(*) as total,userId from verify WHERE logicalDel=0 GROUP BY userId HAVING total=2;"
        data = mysqldb.mysqldb("qywl").selectsql(verifyAuth)
        userId = random.choice(data)["userId"]
        print("aa===》" + userId)

        mallstore = "SELECT id FROM mallStore WHERE userId='" + userId + "' AND logicalDel =0 AND processStatus=2 and status=0";
        data = mysqldb.mysqldb("qywl").selectsql(mallstore)
        if len(data) > 0:
            flag = 0
            print(data)
    print(userId)
    companyAuth = "SELECT phone FROM qywl.users where verifyStatus= 1 AND relationCompany=1 AND id ='" + userId + "';"
    print(companyAuth)
    data = mysqldb.mysqldb("qywl").selectsql(companyAuth)
    change_password = "UPDATE users SET `password` = '$2y$10$4bUxJnAaqiitxaQGvWfAsOnsyP7P61Pe3kUgc79nVw/KrlvOMW/Vm' WHERE id ='" + userId + "';commit"
    print(change_password)
    change_password_data = mysqldb.mysqldb("qywl").selectsql(change_password)
    return random.choice(data)["phone"]


# 获取一个企业认证_店铺信息未完善用户的手机号
def companyAuth_Incomplete():
    flag = 1
    while flag:
        verifyAuth = "SELECT count(*) as total,userId from verify WHERE logicalDel=0 GROUP BY userId HAVING total=2;"
        data = mysqldb.mysqldb("qywl").selectsql(verifyAuth)
        userId = random.choice(data)["userId"]
        print("aa===》" + userId)

        mallstore_Incomplete = "SELECT id FROM mallStore WHERE userId='" + userId + "' AND logicalDel =0 AND processStatus=1 and status=0";
        data = mysqldb.mysqldb("qywl").selectsql(mallstore_Incomplete)
        if len(data) > 0:
            flag = 0
            print(data)
    print(userId)
    companyAuth = "SELECT phone FROM qywl.users where verifyStatus= 1 AND relationCompany=1 AND id ='" + userId + "';"
    print(companyAuth)
    data = mysqldb.mysqldb("qywl").selectsql(companyAuth)
    change_password = "UPDATE users SET `password` = '$2y$10$4bUxJnAaqiitxaQGvWfAsOnsyP7P61Pe3kUgc79nVw/KrlvOMW/Vm' WHERE id ='" + userId + "';commit"
    print(change_password)
    change_password_data = mysqldb.mysqldb("qywl").selectsql(change_password)
    return random.choice(data)["phone"]


# 获取一个测试手机号
def getPhone():
    personAuth = "SELECT phone FROM qywl.users where phone>='16820060000' and phone<='16820069999';"
    data = mysqldb.mysqldb("qywl").selectsql(personAuth)
    return random.choice(data)["phone"]


# 获取一个好友关系
def getfriends():
    '''
    获取拥有好友关系的两个用户的手机号
    :return: 拥有好友关系的两个用户的手机号
    '''
    userids = "select userId,friendsUserId from qywl.friends where status=1 and logicalDel=1 and friendsUserId!='333' and  userId IN (SELECT id from users where phone>='16820060000' and phone<='16820069999');"
    userid_data = mysqldb.mysqldb("qywl").selectsql(userids)
    # print(userid_data)
    friends = random.choice(userid_data)
    phone_a = mysqldb.mysqldb("qywl").selectsql("select phone from qywl.users where id = '%s';" % friends["userId"])[0][
        'phone']
    phone_b = \
        mysqldb.mysqldb("qywl").selectsql("select phone from qywl.users where id ='%s';" % friends["friendsUserId"])[0][
            'phone']

    # print(phone_a, phone_b)
    return phone_a, phone_b


def getQYDuser(type):
    """
    :param type: 1是已开通个人存管账户，2是已开通企业存管账户
    :return: qydphone
    """

    if type == 1:
        # 查询出qyd中已开通个人存管账户且密码为"testche001"的手机号
        personlist = "select tel_num as phone from qydproduction.user u LEFT JOIN qydproduction.xw_user_role xw on u.id=xw.user_id where u.status=23 and u.password='695cafe61e259f1eb22d345e48218109' and xw.`status`=1 ORDER BY createtime desc;"
        personData = mysqldb.mysqldb("qyd").selectsql(personlist)
        personPhone = random.choice(personData)
        # 查询出海马中已使用的个人存管的qyd手机号
        HmPersonList = "SELECT phone from qywl.verify WHERE type=1"
        HmPersonData = mysqldb.mysqldb("qywl").selectsql(HmPersonList)

        if personPhone in HmPersonData:
            personPhone = random.choice(personData)
        else:
            return personPhone["phone"]

    elif type == 2:
        # 查询出qyd中已开通企业存管账户且密码为"testche001"的手机号
        companylist = "select tel_num as phone from qydproduction.user u LEFT JOIN qydproduction.xw_user_role xw on u.id=xw.user_id where u.status=45 and u.password='695cafe61e259f1eb22d345e48218109' and type='Company' and xw.`status`=1 ORDER BY createtime desc;"
        companyData = mysqldb.mysqldb("qyd").selectsql(companylist)
        companyPhone = random.choice(companyData)
        # 查询出海马中已使用的企业存管的qyd手机号
        HmCompanyList = "SELECT phone from qywl.verify WHERE type=2"
        HmCompanyData = mysqldb.mysqldb("qywl").selectsql(HmCompanyList)
        if companyPhone in HmCompanyData:
            companyPhone = random.choice(HmCompanyData)
        else:
            return companyPhone["phone"]
    else:
        print("请输入正确的type值：1是已开通个人存管账户，2是已开通企业存管账户")


def verify(phone, status):
    """
    企业认证审核
    :param phone: 提交资料的人的手机号
    :param status: 审核通过为1，审核驳回为4
    :return:
    """
    url = hmlt_base_admin_url + '/api/v3/verify/verify'

    admintoken = mysqldb.mysqldb("qywl").selectsql("select api_token from qywl.admin where name='root'")[0]['api_token']
    idsql = "select id from qywl.companyVerifyApply where userPhone='%s' and logicalDel=1" % phone
    id = mysqldb.mysqldb("qywl").selectsql(idsql)[0]['id']
    headers = {"Content-Type": "application/json", "Authorization": admintoken}
    if status == '1':
        params = {'id': id, 'status': status, 'remark': '测试审核通过'}
    elif status == '4':
        params = {'id': id, 'status': status, 'remark': '测试审核驳回'}
    else:
        print("输入类型错误：审核通过status为1，审核驳回status为4")
    res = requests.post(url=url, headers=headers, params=params, verify=False)
    if res.json()['code'] == 10000:
        # print("审核成功")
        return 'ok'
    else:
        # print(res.json())
        return res.json()['msg']


def genNumByLength(length):
    """
    生成指定位数的随机数
    :param length: 需要生成随机数的位数
    :return: str类型的length个数
    """
    num = ""
    while length > 0:
        num += str(random.randint(0, 9))
        length = length - 1
    return num


# 获取一个发送者的手机号
def send_workloguser():
    # 获取公司id，且至少有3个员工
    company_id = "select companyId from enterprise.employee WHERE logicalDel = 0 GROUP BY companyId HAVING count(employee.id)>=3;"
    data = mysqldb.mysqldb("enterprise").selectsql(company_id)
    res_companyId = random.choice(data)["companyId"]

    # 获取员工id
    sql_employeeId = "select employeeId from employeeRole where companyId ='%s' and role = 1 and logicalDel = 0;" % res_companyId
    res_employeeId = mysqldb.mysqldb("enterprise").selectsql(sql_employeeId)
    print(res_employeeId)
    get_employeeId = res_employeeId[0]['employeeId']

    # 获取用户id
    get_userid = "select userId from employee where employee.id ='%s';" % get_employeeId
    res_userid = mysqldb.mysqldb("enterprise").selectsql(get_userid)
    prise_userid = res_userid[0]['userId']

    # 获取手机号码
    change_pw = "update users SET `password`='$2y$10$4bUxJnAaqiitxaQGvWfAsOnsyP7P61Pe3kUgc79nVw/KrlvOMW/Vm' WHERE id = '%s';" % prise_userid
    mysqldb.mysqldb("qywl").updatesql(change_pw)
    get_phone = "select phone from users where id ='%s';" % prise_userid
    res_phone = mysqldb.mysqldb("qywl").selectsql(get_phone)
    return res_phone[0]['phone']


# 获取发送者所属公司的一个接收者
def recv_workloguser(phone):
    # 获取发出方id
    get_userid = "select id from users WHERE phone= '%s';" % phone
    data = mysqldb.mysqldb("qywl").selectsql(get_userid)
    res_userid = data[0]['id']

    # 获取公司id
    get_companyid = "select companyId from employee where userId = '%s';" % res_userid
    res_companyid = mysqldb.mysqldb("enterprise").selectsql(get_companyid)
    prise_companyId = res_companyid[0]['companyId']

    # 获取接收者id
    get_employeeId = "select * from employee where companyId ='%s' and logicalDel = 0;" % prise_companyId
    res_employeeId = mysqldb.mysqldb("enterprise").selectsql(get_employeeId)
    res_usersid = res_employeeId[1]['userId']
    change_pw = "update users SET `password`='$2y$10$4bUxJnAaqiitxaQGvWfAsOnsyP7P61Pe3kUgc79nVw/KrlvOMW/Vm' WHERE id = '%s';" % res_usersid
    mysqldb.mysqldb("qywl").updatesql(change_pw)

    # 获取接受者手机号
    get_recvphone = "select phone from users WHERE id= '%s';" % res_usersid
    res_recvphone = mysqldb.mysqldb("qywl").selectsql(get_recvphone)
    print(res_recvphone[0]['phone'])
    return res_recvphone[0]['phone']


# 获取jenkins打包时间及分支信息
def jenkins_lastBuild_info():
    jenkins_url = madb().get_jenkins_url()
    jenkins_url = jenkins_url + '/api/json'
    # url = 'http://staging-ops.situdata.com/jenkins/job/%E4%B8%AD%E5%AE%8F%E4%BA%BA%E5%AF%BF-android-staging-A%E7%AB' \
    #       '%AF/api/json'
    username = "wangqian@situdata.com"
    password = "Pisen666"
    auth = username + ":" + password
    headers = {"Content-Type": "application/json", 'Connection': 'close',
               "Authorization": "Basic " + base64.b64encode(auth.encode(encoding="utf-8")).decode(encoding='utf-8')}
    response = requests.get(jenkins_url, headers=headers, verify=False)
    res = response.json()
    jenkins_branch = res['displayName']
    last_url = 'http://staging-ops.situdata.com' + \
               res['lastBuild']['url'].replace('http://jenkins.situdata.com', '') + 'api/json'
    response = requests.get(last_url, headers=headers, verify=False)
    res = response.json()
    timestamp = res['timestamp']

    return jenkins_branch, timestamp


if __name__ == '__main__':
    # send_workloguser()
    # recv_workloguser()
    # manager_user()
    # friends = getfriends()
    # print(friends[0], friends[1])
    # getRandomPhone()
    print(companyAuth())
