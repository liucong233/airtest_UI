# -*- coding: utf-8 -*-
# author:lcy

from poco.drivers.android.uiautomation import AndroidUiautomationPoco

poco = AndroidUiautomationPoco()

# 提醒弹框
dialog_close = poco("com.qywlandroid:id/dialog_close")
# huawei,oneplus,samsung 权限弹框
permission_message = poco("com.android.packageinstaller:id/permission_message")
# oppo 权限弹框
permission_setting_prompt = poco("com.coloros.safecenter:id/permission_setting_prompt")
# huawei,oneplus,samsung 允许 正则匹配
permission_allow = poco(textMatches='.*允许')

# *******版本更新******
dialog_update_content = poco("com.qywlandroid:id/dialog_update_content")
dialog_update_close = poco("com.qywlandroid:id/dialog_update_close")
dialog_updata_apk = poco("com.qywlandroid:id/dialog_update_apk")

# ******登录******
phone = poco("com.qywlandroid:id/et_complete_input")
password = poco("com.qywlandroid:id/et_login_password")
login = poco("com.qywlandroid:id/rl_container")

# 我的
e_mine = "com.qywlandroid:id/iv_mine"
# 消息
e_message = "com.qywlandroid:id/iv_home"

# ******发现******
# 发现
e_find = "com.qywlandroid:id/iv_message"
# 朋友圈
e_friend = "com.qywlandroid:id/tv_circleoffriends"

# ******朋友圈列表******
# 返回按钮
e_back = "com.qywlandroid:id/iv_back"
# 封面
e_cover = "com.qywlandroid:id/iv_cover"
# 头像
e_head = "com.qywlandroid:id/iv_head"
# 昵称
e_nickname = "com.qywlandroid:id/tv_nickname"
# 简介
e_intro = "com.qywlandroid:id/tv_autograph"
# 提到了谁
e_mention_friend = "com.qywlandroid:id/tv_mention_friend "
# 删除动态
e_del_content = "com.qywlandroid:id/tv_delete"
# 发布
e_post = "com.qywlandroid:id/iv_camera"
# 文字0、图片1、视频2
e_post_type = "com.qywlandroid:id/it_item"
# 赞
e_like = "com.qywlandroid:id/tv_like"
# 评论
e_comment = "com.qywlandroid:id/tv_comment"
# 评论输入框
e_comment_content = "com.qywlandroid:id/et_content"
# 发送评论
e_comment_confirm = "com.qywlandroid:id/bt_send"
# emoji
e_emoji = "com.qywlandroid:id/iv_emoji"
# 删除动态/评论确认
e_del_confirm = "com.qywlandroid:id/tv_pop_item1"
# 点赞列表
e_like_list = "com.qywlandroid:id/tv_praise"
# 评论列表
e_comment_list = "com.qywlandroid:id/textView"
# 动态的图片列表
e_content_img_list = "com.qywlandroid:id/nineGrid"
# 动态的图片
e_content_img = "android.widget.ImageView"
# 大图预览
e_img_big = "com.qywlandroid:id/pv"
# 动态的视频
e_vedio = "com.qywlandroid:id/iv_video_thumb"

# ******发布动态******
# title
e_title_post = "发布动态"
# 输入框
e_content = "com.qywlandroid:id/et_dynamic_content"
# at
e_prompt = "com.qywlandroid:id/tv_prompt"
# atlist
e_at_list = "com.qywlandroid:id/rv_user_list"
# 发布
e_post_confirm = "com.qywlandroid:id/btn_comfirm"
# 上传图片
e_img_post = "com.qywlandroid:id/iv_dynamic_img"
# 已上传图片列表
e_img_list = "com.qywlandroid:id/rv_photo_list"
# 从相册中选择
e_vedio_album = "com.qywlandroid:id/tv_pop_item2"
# 拍照选择
e_shoot = "com.qywlandroid:id/tv_pop_item1"

# ******提醒谁看******
# 搜索
e_search_friends = "com.qywlandroid:id/edit_search_friends "
# 选择好友
e_atfriends = "com.qywlandroid:id/cb_friends"
# 选择结果
e_select_result = "com.qywlandroid:id/rv_select_result"
# 确认
e_at_confirm = "com.qywlandroid:id/tv_toolbar_right"

# ******选择图片******
# 选择图片
e_img_check = "com.qywlandroid:id/iv_item_check"
# 图片
e_img = "com.qywlandroid:id/iv_photo"
# 图片确认
e_img_commit = "com.qywlandroid:id/tv_actionBar_commit"
# 封面确认
e_cover_confirm = "com.qywlandroid:id/tv_toolbar_right"

# ******我发布的******
# 朋友圈tab
e_friend_tab = "com.qywlandroid:id/tv_friend_circle"
# 生意圈tab
e_business_tab = "com.qywlandroid:id/tv_business_circle"
# 上传
e_mine_post = "com.qywlandroid:id/iv_one_pic"

# ******个人主页******
# 朋友圈预览图片
e_friend_review = "com.qywlandroid:id/iv_friend_review"
# ID
e_user_id = "com.qywlandroid:id/tv_user_id"
# 地区
e_address = "com.qywlandroid:id/tv_address"
# 简介
e_user_intro = "com.qywlandroid:id/tv_user_intro"
# 朋友圈入口
e_friend_circle = "com.qywlandroid:id/rl_friend_circle"
# 生意圈入口
e_business_circle = "com.qywlandroid:id/rl_trade_circle"
# 更多...
e_iv_more = "com.qywlandroid:id/iv_more"

#
ui_sendmsg = "com.qywlandroid:id/buttonSendMessage"
ui_editTextMessage = "com.qywlandroid:id/editTextMessage"
