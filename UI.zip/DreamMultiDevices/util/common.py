# -*- coding:utf-8 -*-
# author:lcy

import os
from util import commonElement
from airtest.core.api import *
from airtest.core.android.adb import ADB
import PIL
from poco.drivers.android.uiautomation import AndroidUiautomationPoco

poco = AndroidUiautomationPoco()

PWD = os.path.dirname(__file__)
PKG = "com.qywlandroid"
APK = os.path.join(PWD, "haima-QA-072502.apk")
par_dir = os.path.abspath(os.path.join(PWD, os.path.pardir))
Template_dir = par_dir + '\\TestCaseImage\\'

_print = print


def print(*args, **kwargs):
    _print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), *args, **kwargs)


def checkapp():
    # 待完善
    if PKG not in device().list_app():
        install(APK)


def login(phone, password):
    # 每个函数都需要分别实例poco,解决多设备时，函数调用找不到元素问题
    poco = AndroidUiautomationPoco()
    num = 0
    while num <= 1:

        dialog = poco("com.qywlandroid:id/dialog_close")
        permission_message = poco("com.android.packageinstaller:id/permission_message")
        permission_setting_prompt = poco("com.coloros.safecenter:id/permission_setting_prompt")
        permission_allow = poco(textMatches='.*允许')
        username = poco("com.qywlandroid:id/et_complete_input")
        user_pwd = poco("com.qywlandroid:id/et_login_password")
        login = poco("com.qywlandroid:id/rl_container")
        dialog_update_content = poco("com.qywlandroid:id/dialog_update_content")
        dialog_update_close = poco("com.qywlandroid:id/dialog_update_close")

        try:
            # ui = poco.dismiss([phone, permission, dialog], appearance_timeout=3)
            ui = poco.wait_for_any([username, permission_message, dialog, dialog_update_content], timeout=3)
        except:
            break
        # 处理登录
        if ui is username:
            username.click()
            username.set_text(phone)
            user_pwd.set_text(password)
            login.click()
            poco(commonElement.e_mine).wait().exists()
            num = num + 1

        # 登录弹框
        elif ui is dialog:
            keyevent('BACK')

        # 权限弹框
        elif ui is permission_message or permission_setting_prompt:
            permission_allow.click()

        # 更新弹框
        elif ui is dialog_update_content:
            dialog_update_close.click()

        sleep(1)


# 回到 app主页面（消息、通讯录、发现、我的）
def back_wait_element():
    """
    back to the main_menu
    :return:
    """
    poco = AndroidUiautomationPoco()

    # num>5时强制结束，防止app异常退出导致死循环
    num = 0
    while poco(commonElement.e_mine).wait(1).exists() is False:
        keyevent("BACK")
        num += 1
        if num == 5:
            break


# 退出登录
def quit():
    """
    logout
    :return:
    """
    poco = AndroidUiautomationPoco()

    poco(commonElement.e_mine).wait(2).click()
    poco(text="设置").click()
    sleep(1)

    # 设置
    # blacklist = poco(text="黑名单")
    poco(text="退出登录").click()
    poco("com.qywlandroid:id/tv_pop_item2").click()
    sleep(2)
    poco("com.qywlandroid:id/et_complete_input")


# 检测是否有相册权限系统弹框
def pic_perm():
    poco = AndroidUiautomationPoco()
    # 待优化
    while True:
        permission = poco("com.android.packageinstaller:id/perm_desc_root")
        permission_allow = poco("com.android.packageinstaller:id/permission_allow_button")
        dialog = poco("com.qywlandroid:id/dialog_close")
        pic = poco("com.qywlandroid:id/iv_item_image")

        try:
            ui = poco.wait_for_any([pic, permission, dialog], timeout=3)
        except:
            break
        if ui is pic:
            break

        elif ui is dialog:
            dialog.click()


        elif ui is permission:
            permission_allow.click()
            sleep(1)


# 截取指定高度的图片
def Screenshot_cover():
    # 待补充
    poco = AndroidUiautomationPoco()

    size = poco.get_screen_size()
    print(size)


# 使用安卓系统粘贴功能
def paste():
    '''
    white_paste.png为华为、一加、小米系统的粘贴按钮截图
    black_paste.png为oppo，vivo系统的粘贴按钮截图
    有一定的识别失败概率
    :return:
    '''
    poco = AndroidUiautomationPoco()
    poco(commonElement.ui_editTextMessage).long_click(2)
    sleep(2)
    screen_size = poco.get_screen_size()
    if exists(Template(Template_dir + r"white_paste.png", threshold=0.5, record_pos=(-0.212, 0.587),
                       resolution=(screen_size[0], screen_size[1]))):
        touch(Template(Template_dir + r"white_paste.png", threshold=0.5, record_pos=(-0.212, 0.587),
                       resolution=(screen_size[0], screen_size[1])))
        return 'ok'
    elif exists(Template(Template_dir + r"black_paste.png", threshold=0.5, record_pos=(-0.349, 0.881),
                         resolution=(screen_size[0], screen_size[1]))):
        touch(Template(Template_dir + r"black_paste.png", threshold=0.5, record_pos=(-0.349, 0.881),
                       resolution=(screen_size[0], screen_size[1])))
        return 'ok'
    else:
        return 'fail'


def delTBS():
    """
    去掉腾讯TBS内核，建议有H5页面的用例执行前使用该方法：登录后使用该方法，去掉后将重启app
    :return:
    """
    poco("com.qywlandroid:id/iv_home").click()
    poco("com.qywlandroid:id/tv_name").click()
    poco("com.qywlandroid:id/editTextMessage").set_text("debugtbs.qq.com")
    poco("com.qywlandroid:id/emoji_button").click()
    # poco("com.qywlandroid:id/imgEmoji").click()
    poco("com.qywlandroid:id/buttonSendMessage").click()
    poco(text="debugtbs.qq.com").click()
    #    poco(text="清除TBS内核").wait(7).click()
    poco(text="DebugX5").wait(7).click()
    poco(text="信息").wait(7).click()
    poco(text="确定").click()
    stop_app("com.qywlandroid")
    start_app("com.qywlandroid")


# def update():
#     """版本更新，进入页面关掉版本更新提示--刘倩倩"""
#     if exists(Template(Template_dir+r"tpl1574760079003.png", record_pos=(-0.161, -0.161), resolution=(1080, 1920))):
#         poco("com.qywlandroid:id/dialog_update_close").click()
#     else:
#         pass

def Business_circle_shop():
    """进入生意圈，判断店铺信息是否需要完善--刘倩倩"""
    poco = AndroidUiautomationPoco()
    poco(name='com.qywlandroid:id/iv_message').wait(2).click()
    poco(text='生意圈').click()
    # wait(Template(Template_dir + r"tpl1571127405712.png",threshold=0.5, record_pos=(0.003, -0.765), resolution=(1080, 1920)))
    poco(name="com.qywlandroid:id/tv_toolbar_right").wait(5).click()
    sleep(5)
    if poco(text="您的商城有更新，赶快去完善店铺信息吧，让用户更好的了解！").exists():
        poco(text="暂不完善").click()
    else:
        print("店铺信息完整不需要补充")


def Delete_service():
    """删除生意圈服务--刘倩倩"""
    poco = AndroidUiautomationPoco()
    # wait(Template(Template_dir + r"tpl1571127653905.png",threshold=0.5, record_pos=(0.005, -0.766), resolution=(1080, 1920)))
    sleep(3)
    poco("android.widget.ListView").child("android.view.View")[0].child("android.view.View")[0].wait(5).click()
    # assert_exists(
    #     Template(Template_dir + r"tpl1571214763832.png",threshold=0.5, record_pos=(-0.003, -0.019), resolution=(1080, 1920)),
    #     "是否正常弹出删除服务提示框")
    poco("app").child("android.view.View")[2].child("android.view.View").child("android.widget.Button")[0].wait(
        2).click()  # 取消弹框
    poco("android.widget.ListView").child("android.view.View")[0].child("android.view.View")[0].click()  # 重新打开弹框
    poco("app").child("android.view.View")[2].child("android.view.View").child("android.widget.Button")[1].click()
    poco("app").child("android.view.View")[0].child("android.view.View").child("android.view.View")[1].child(
        "android.widget.Image").wait(2).click()  # 删除服务后，返回生意圈页面
    poco("com.qywlandroid:id/tv_toolbar_left").wait(2).click()  # 返回至发现页
# login("15810061903","123456")

# back_wait_element()
