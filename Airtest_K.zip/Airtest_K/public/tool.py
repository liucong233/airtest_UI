from poco.drivers.android.uiautomation import AndroidUiautomationPoco

class Tools(AndroidUiautomationPoco):
    pass
